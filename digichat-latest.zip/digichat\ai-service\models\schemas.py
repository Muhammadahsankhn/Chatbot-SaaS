from pydantic import BaseModel
from typing import Optional, List

# ── Incoming request from Node.js ──
class ChatRequest(BaseModel):
    message: str
    sessionId: str
    userId: str
    botConfig: Optional[dict] = {}
    # botConfig can carry: botName, welcomeMessage, systemPrompt

# ── Single message in history ──
class MessageHistory(BaseModel):
    role: str        # "user" or "model"
    text: str

# ── Request with conversation history for context ──
class ChatWithHistoryRequest(BaseModel):
    message: str
    sessionId: str
    userId: str
    history: Optional[List[MessageHistory]] = []
    botConfig: Optional[dict] = {}

# ── Response back to Node.js ──
class ChatResponse(BaseModel):
    success: bool
    reply: str
    sessionId: str
    tokensUsed: Optional[int] = None
    error: Optional[str] = None 